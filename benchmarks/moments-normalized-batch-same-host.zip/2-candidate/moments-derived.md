# Native function performance versus scikit-image

Every native public function is checked before timing. Fallback is disabled; forwarding to scikit-image cannot count as native performance. Reference thread pools use one thread. Numbers are medians of warmed allocation-inclusive calls on seeded synthetic images. Identity calls return the input unchanged; metadata calls return small values/arrays without processing pixels. Speedup is reference/current; below 1 means slower. This does not prove full API parity or universal performance. Fixed owning 4x4 moment tensors are prepared outside timing; dtype is the actual mu/nu input dtype, not an image label. Normalization uses bounded native batch arithmetic for assessed contiguous 4x4 real defaults; its scalar fallback retains NumPy powers, first division, promotion and assignment with an owned final divide. Hu keeps dtype conversion and output wrapping around owned C++ polynomial arithmetic. Each timed public call includes its allocation, eligibility checks and conversions. Integer normalization has exact source-error coverage and no timing row.

| API | Size | Dtype | Workers | Execution | Reference ms | Current ms | Speedup |
|---|---:|---|---:|---|---:|---:|---:|
| measure.moments_hu | 4 | uint8 | 1 | native | 0.0039 | 0.0029 | 1.35x |
| measure.moments_normalized | 4 | float32 | 1 | native | 0.0499 | 0.0024 | 20.97x |
| measure.moments_hu | 4 | float32 | 1 | native | 0.0027 | 0.0022 | 1.21x |
| measure.moments_normalized | 4 | float64 | 1 | native | 0.0275 | 0.0023 | 11.90x |
| measure.moments_hu | 4 | float64 | 1 | native | 0.0031 | 0.0024 | 1.31x |
