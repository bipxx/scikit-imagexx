# Native function performance versus scikit-image

Every native public function is checked before timing. Fallback is disabled; forwarding to scikit-image cannot count as native performance. Reference thread pools use one thread. Numbers are medians of warmed allocation-inclusive calls on seeded synthetic images. Identity calls return the input unchanged; metadata calls return small values/arrays without processing pixels. Speedup is reference/current; below 1 means slower. This does not prove full API parity or universal performance. Fixed owning 4x4 moment tensors are prepared outside timing; dtype is the actual mu/nu input dtype, not an image label. Normalization keeps NumPy scalar powers, first division, promotion and assignment providers with an owned final scalar divide; Hu keeps dtype conversion and output wrapping around owned C++ polynomial arithmetic. Each timed public call includes its own allocation and conversions. Integer normalization raises the source NaN-assignment error and has no timing row.

| API | Size | Dtype | Workers | Execution | Reference ms | Current ms | Speedup |
|---|---:|---|---:|---|---:|---:|---:|
| measure.moments_hu | 4 | uint8 | 1 | native | 0.0035 | 0.0030 | 1.18x |
| measure.moments_normalized | 4 | float32 | 1 | native | 0.0494 | 0.1204 | 0.41x |
| measure.moments_hu | 4 | float32 | 1 | native | 0.0029 | 0.0020 | 1.47x |
| measure.moments_normalized | 4 | float64 | 1 | native | 0.0274 | 0.0904 | 0.30x |
| measure.moments_hu | 4 | float64 | 1 | native | 0.0030 | 0.0024 | 1.24x |
