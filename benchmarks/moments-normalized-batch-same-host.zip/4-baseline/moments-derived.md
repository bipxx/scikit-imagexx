# Native function performance versus scikit-image

Every native public function is checked before timing. Fallback is disabled; forwarding to scikit-image cannot count as native performance. Reference thread pools use one thread. Numbers are medians of warmed allocation-inclusive calls on seeded synthetic images. Identity calls return the input unchanged; metadata calls return small values/arrays without processing pixels. Speedup is reference/current; below 1 means slower. This does not prove full API parity or universal performance. Fixed owning 4x4 moment tensors are prepared outside timing; dtype is the actual mu/nu input dtype, not an image label. Normalization keeps NumPy scalar powers, first division, promotion and assignment providers with an owned final scalar divide; Hu keeps dtype conversion and output wrapping around owned C++ polynomial arithmetic. Each timed public call includes its own allocation and conversions. Integer normalization raises the source NaN-assignment error and has no timing row.

| API | Size | Dtype | Workers | Execution | Reference ms | Current ms | Speedup |
|---|---:|---|---:|---|---:|---:|---:|
| measure.moments_hu | 4 | uint8 | 1 | native | 0.0034 | 0.0029 | 1.18x |
| measure.moments_normalized | 4 | float32 | 1 | native | 0.0475 | 0.1183 | 0.40x |
| measure.moments_hu | 4 | float32 | 1 | native | 0.0027 | 0.0021 | 1.29x |
| measure.moments_normalized | 4 | float64 | 1 | native | 0.0265 | 0.0893 | 0.30x |
| measure.moments_hu | 4 | float64 | 1 | native | 0.0028 | 0.0021 | 1.29x |
