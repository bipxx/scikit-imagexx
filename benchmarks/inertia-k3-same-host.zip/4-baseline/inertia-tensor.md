# Native function performance versus scikit-image

Every native public function is checked before timing. Fallback is disabled; forwarding to scikit-image cannot count as native performance. Reference thread pools use one thread. Numbers are medians of warmed allocation-inclusive calls on seeded synthetic images. Identity calls return the input unchanged; metadata calls return small values/arrays without processing pixels. Speedup is reference/current; below 1 means slower. This does not prove full API parity or universal performance. Automatic central moments use owned per-axis projections; NumPy coordinate powers, analytical preparation, diagonal summation and indexing remain providers. Finite real tensor assembly is owned C++; exceptional arithmetic retains local NumPy expressions. Both timed public calls include moments, tensor allocation and preparation; genuine original central moments are separately prepared outside timing only for the frozen per-cell checker.

| API | Size | Dtype | Workers | Execution | Reference ms | Current ms | Speedup |
|---|---:|---|---:|---|---:|---:|---:|
| measure.inertia_tensor | 256 | uint8 | 1 | native | 0.3231 | 0.2998 | 1.08x |
| measure.inertia_tensor | 256 | float32 | 1 | native | 0.2889 | 0.1891 | 1.53x |
| measure.inertia_tensor | 256 | float64 | 1 | native | 0.3069 | 0.2811 | 1.09x |
| measure.inertia_tensor | 1024 | uint8 | 1 | native | 1.6990 | 5.0139 | 0.34x |
| measure.inertia_tensor | 1024 | float32 | 1 | native | 1.2573 | 3.1079 | 0.40x |
| measure.inertia_tensor | 1024 | float64 | 1 | native | 1.4477 | 4.8453 | 0.30x |
