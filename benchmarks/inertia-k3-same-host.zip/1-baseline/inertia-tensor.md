# Native function performance versus scikit-image

Every native public function is checked before timing. Fallback is disabled; forwarding to scikit-image cannot count as native performance. Reference thread pools use one thread. Numbers are medians of warmed allocation-inclusive calls on seeded synthetic images. Identity calls return the input unchanged; metadata calls return small values/arrays without processing pixels. Speedup is reference/current; below 1 means slower. This does not prove full API parity or universal performance. Automatic central moments use owned per-axis projections; NumPy coordinate powers, analytical preparation, diagonal summation and indexing remain providers. Finite real tensor assembly is owned C++; exceptional arithmetic retains local NumPy expressions. Both timed public calls include moments, tensor allocation and preparation; genuine original central moments are separately prepared outside timing only for the frozen per-cell checker.

| API | Size | Dtype | Workers | Execution | Reference ms | Current ms | Speedup |
|---|---:|---|---:|---|---:|---:|---:|
| measure.inertia_tensor | 256 | uint8 | 1 | native | 0.3169 | 0.2977 | 1.06x |
| measure.inertia_tensor | 256 | float32 | 1 | native | 0.2890 | 0.1938 | 1.49x |
| measure.inertia_tensor | 256 | float64 | 1 | native | 0.2987 | 0.2443 | 1.22x |
| measure.inertia_tensor | 1024 | uint8 | 1 | native | 1.6653 | 5.2557 | 0.32x |
| measure.inertia_tensor | 1024 | float32 | 1 | native | 1.2437 | 2.1203 | 0.59x |
| measure.inertia_tensor | 1024 | float64 | 1 | native | 1.4959 | 6.8195 | 0.22x |
