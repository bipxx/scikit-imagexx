# Native function performance versus scikit-image

Every native public function is checked before timing. Fallback is disabled; forwarding to scikit-image cannot count as native performance. Reference thread pools use one thread. Numbers are medians of warmed allocation-inclusive calls on seeded synthetic images. Identity calls return the input unchanged; metadata calls return small values/arrays without processing pixels. Speedup is reference/current; below 1 means slower. This does not prove full API parity or universal performance. Automatic central moments use owned per-axis projections; NumPy coordinate powers, analytical preparation, diagonal summation and indexing remain providers. Finite real tensor assembly is owned C++; exceptional arithmetic retains local NumPy expressions. Both timed public calls include moments, tensor allocation and preparation; genuine original central moments are separately prepared outside timing only for the frozen per-cell checker.

| API | Size | Dtype | Workers | Execution | Reference ms | Current ms | Speedup |
|---|---:|---|---:|---|---:|---:|---:|
| measure.inertia_tensor | 256 | uint8 | 1 | native | 0.3101 | 0.2037 | 1.52x |
| measure.inertia_tensor | 256 | float32 | 1 | native | 0.2912 | 0.1727 | 1.69x |
| measure.inertia_tensor | 256 | float64 | 1 | native | 0.3015 | 0.1885 | 1.60x |
| measure.inertia_tensor | 1024 | uint8 | 1 | native | 1.6291 | 1.1125 | 1.46x |
| measure.inertia_tensor | 1024 | float32 | 1 | native | 1.2511 | 0.8528 | 1.47x |
| measure.inertia_tensor | 1024 | float64 | 1 | native | 1.4133 | 0.9409 | 1.50x |
