# Native function performance versus scikit-image

Every native public function is checked before timing. Fallback is disabled; forwarding to scikit-image cannot count as native performance. Reference thread pools use one thread. Numbers are medians of warmed allocation-inclusive calls on seeded synthetic images. Identity calls return the input unchanged; metadata calls return small values/arrays without processing pixels. Speedup is reference/current; below 1 means slower. This does not prove full API parity or universal performance. Automatic central moments use owned per-axis projections; NumPy coordinate powers, analytical preparation, diagonal summation and indexing remain providers. Finite real tensor assembly is owned C++; exceptional arithmetic retains local NumPy expressions. Both timed public calls include moments, tensor allocation and preparation; genuine original central moments are separately prepared outside timing only for the frozen per-cell checker.

| API | Size | Dtype | Workers | Execution | Reference ms | Current ms | Speedup |
|---|---:|---|---:|---|---:|---:|---:|
| measure.inertia_tensor | 256 | uint8 | 1 | native | 0.3142 | 0.2006 | 1.57x |
| measure.inertia_tensor | 256 | float32 | 1 | native | 0.2907 | 0.1736 | 1.67x |
| measure.inertia_tensor | 256 | float64 | 1 | native | 0.2975 | 0.1892 | 1.57x |
| measure.inertia_tensor | 1024 | uint8 | 1 | native | 1.5860 | 0.9534 | 1.66x |
| measure.inertia_tensor | 1024 | float32 | 1 | native | 1.2483 | 0.8568 | 1.46x |
| measure.inertia_tensor | 1024 | float64 | 1 | native | 1.5429 | 1.0239 | 1.51x |
