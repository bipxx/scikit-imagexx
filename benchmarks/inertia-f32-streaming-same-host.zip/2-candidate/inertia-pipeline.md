# Native function performance versus scikit-image

Every native public function is checked before timing. Fallback is disabled; forwarding to scikit-image cannot count as native performance. Reference thread pools use one thread. Numbers are medians of warmed allocation-inclusive calls on seeded synthetic images. Identity calls return the input unchanged; metadata calls return small values/arrays without processing pixels. Speedup is reference/current; below 1 means slower. This does not prove full API parity or universal performance. Automatic central moments use owned per-axis projections; NumPy coordinate powers, analytical preparation, diagonal summation and indexing remain providers. Finite real tensor assembly is owned C++; exceptional arithmetic retains local NumPy expressions. Both timed public calls include moments, tensor allocation and preparation; genuine original central moments are separately prepared outside timing only for the frozen per-cell checker. Default image calls include owned moments, inertia assembly and the existing C++ symmetric eigensolver; NumPy preparation, clipping and scalar-list wrapping remain providers. Unsupported solver domains retain NumPy eigvalsh primitives without native solver credit. Genuine original central moments and tensor are prepared outside timing only for the frozen solver-plus-Weyl checker.

| API | Size | Dtype | Workers | Execution | Reference ms | Current ms | Speedup |
|---|---:|---|---:|---|---:|---:|---:|
| measure.inertia_tensor | 256 | uint8 | 1 | native | 0.1399 | 0.1021 | 1.37x |
| measure.inertia_tensor_eigvals | 256 | uint8 | 1 | native | 0.1729 | 0.1254 | 1.38x |
| measure.inertia_tensor | 256 | float32 | 1 | native | 0.1198 | 0.0853 | 1.41x |
| measure.inertia_tensor_eigvals | 256 | float32 | 1 | native | 0.1525 | 0.1032 | 1.48x |
| measure.inertia_tensor | 256 | float64 | 1 | native | 0.1287 | 0.0980 | 1.31x |
| measure.inertia_tensor_eigvals | 256 | float64 | 1 | native | 0.1624 | 0.1172 | 1.39x |
| measure.inertia_tensor | 1024 | uint8 | 1 | native | 0.7476 | 0.5486 | 1.36x |
| measure.inertia_tensor_eigvals | 1024 | uint8 | 1 | native | 0.7876 | 0.5746 | 1.37x |
| measure.inertia_tensor | 1024 | float32 | 1 | native | 0.6337 | 0.2562 | 2.47x |
| measure.inertia_tensor_eigvals | 1024 | float32 | 1 | native | 0.6866 | 0.2818 | 2.44x |
| measure.inertia_tensor | 1024 | float64 | 1 | native | 0.5946 | 0.3947 | 1.51x |
| measure.inertia_tensor_eigvals | 1024 | float64 | 1 | native | 0.6277 | 0.4125 | 1.52x |
