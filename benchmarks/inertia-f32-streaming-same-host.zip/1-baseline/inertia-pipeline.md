# Native function performance versus scikit-image

Every native public function is checked before timing. Fallback is disabled; forwarding to scikit-image cannot count as native performance. Reference thread pools use one thread. Numbers are medians of warmed allocation-inclusive calls on seeded synthetic images. Identity calls return the input unchanged; metadata calls return small values/arrays without processing pixels. Speedup is reference/current; below 1 means slower. This does not prove full API parity or universal performance. Automatic central moments use owned per-axis projections; NumPy coordinate powers, analytical preparation, diagonal summation and indexing remain providers. Finite real tensor assembly is owned C++; exceptional arithmetic retains local NumPy expressions. Both timed public calls include moments, tensor allocation and preparation; genuine original central moments are separately prepared outside timing only for the frozen per-cell checker. Default image calls include owned moments, inertia assembly and the existing C++ symmetric eigensolver; NumPy preparation, clipping and scalar-list wrapping remain providers. Unsupported solver domains retain NumPy eigvalsh primitives without native solver credit. Genuine original central moments and tensor are prepared outside timing only for the frozen solver-plus-Weyl checker.

| API | Size | Dtype | Workers | Execution | Reference ms | Current ms | Speedup |
|---|---:|---|---:|---|---:|---:|---:|
| measure.inertia_tensor | 256 | uint8 | 1 | native | 0.1405 | 0.1069 | 1.31x |
| measure.inertia_tensor_eigvals | 256 | uint8 | 1 | native | 0.1761 | 0.1254 | 1.40x |
| measure.inertia_tensor | 256 | float32 | 1 | native | 0.1153 | 0.0845 | 1.36x |
| measure.inertia_tensor_eigvals | 256 | float32 | 1 | native | 0.1517 | 0.1039 | 1.46x |
| measure.inertia_tensor | 256 | float64 | 1 | native | 0.1255 | 0.0988 | 1.27x |
| measure.inertia_tensor_eigvals | 256 | float64 | 1 | native | 0.1638 | 0.1188 | 1.38x |
| measure.inertia_tensor | 1024 | uint8 | 1 | native | 0.7473 | 0.5401 | 1.38x |
| measure.inertia_tensor_eigvals | 1024 | uint8 | 1 | native | 0.7794 | 0.5645 | 1.38x |
| measure.inertia_tensor | 1024 | float32 | 1 | native | 0.6735 | 0.5109 | 1.32x |
| measure.inertia_tensor_eigvals | 1024 | float32 | 1 | native | 0.6970 | 0.5359 | 1.30x |
| measure.inertia_tensor | 1024 | float64 | 1 | native | 0.5870 | 0.3973 | 1.48x |
| measure.inertia_tensor_eigvals | 1024 | float64 | 1 | native | 0.6219 | 0.4209 | 1.48x |
