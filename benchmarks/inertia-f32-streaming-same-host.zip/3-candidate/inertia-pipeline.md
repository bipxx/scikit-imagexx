# Native function performance versus scikit-image

Every native public function is checked before timing. Fallback is disabled; forwarding to scikit-image cannot count as native performance. Reference thread pools use one thread. Numbers are medians of warmed allocation-inclusive calls on seeded synthetic images. Identity calls return the input unchanged; metadata calls return small values/arrays without processing pixels. Speedup is reference/current; below 1 means slower. This does not prove full API parity or universal performance. Automatic central moments use owned per-axis projections; NumPy coordinate powers, analytical preparation, diagonal summation and indexing remain providers. Finite real tensor assembly is owned C++; exceptional arithmetic retains local NumPy expressions. Both timed public calls include moments, tensor allocation and preparation; genuine original central moments are separately prepared outside timing only for the frozen per-cell checker. Default image calls include owned moments, inertia assembly and the existing C++ symmetric eigensolver; NumPy preparation, clipping and scalar-list wrapping remain providers. Unsupported solver domains retain NumPy eigvalsh primitives without native solver credit. Genuine original central moments and tensor are prepared outside timing only for the frozen solver-plus-Weyl checker.

| API | Size | Dtype | Workers | Execution | Reference ms | Current ms | Speedup |
|---|---:|---|---:|---|---:|---:|---:|
| measure.inertia_tensor | 256 | uint8 | 1 | native | 0.1498 | 0.1055 | 1.42x |
| measure.inertia_tensor_eigvals | 256 | uint8 | 1 | native | 0.1836 | 0.1249 | 1.47x |
| measure.inertia_tensor | 256 | float32 | 1 | native | 0.1217 | 0.0849 | 1.43x |
| measure.inertia_tensor_eigvals | 256 | float32 | 1 | native | 0.1558 | 0.1043 | 1.49x |
| measure.inertia_tensor | 256 | float64 | 1 | native | 0.1307 | 0.0952 | 1.37x |
| measure.inertia_tensor_eigvals | 256 | float64 | 1 | native | 0.1646 | 0.1158 | 1.42x |
| measure.inertia_tensor | 1024 | uint8 | 1 | native | 0.7579 | 0.5435 | 1.39x |
| measure.inertia_tensor_eigvals | 1024 | uint8 | 1 | native | 0.7956 | 0.5729 | 1.39x |
| measure.inertia_tensor | 1024 | float32 | 1 | native | 0.6390 | 0.2555 | 2.50x |
| measure.inertia_tensor_eigvals | 1024 | float32 | 1 | native | 0.6767 | 0.2811 | 2.41x |
| measure.inertia_tensor | 1024 | float64 | 1 | native | 0.6114 | 0.3888 | 1.57x |
| measure.inertia_tensor_eigvals | 1024 | float64 | 1 | native | 0.6232 | 0.4049 | 1.54x |
