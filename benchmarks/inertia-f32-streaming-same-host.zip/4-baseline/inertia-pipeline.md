# Native function performance versus scikit-image

Every native public function is checked before timing. Fallback is disabled; forwarding to scikit-image cannot count as native performance. Reference thread pools use one thread. Numbers are medians of warmed allocation-inclusive calls on seeded synthetic images. Identity calls return the input unchanged; metadata calls return small values/arrays without processing pixels. Speedup is reference/current; below 1 means slower. This does not prove full API parity or universal performance. Automatic central moments use owned per-axis projections; NumPy coordinate powers, analytical preparation, diagonal summation and indexing remain providers. Finite real tensor assembly is owned C++; exceptional arithmetic retains local NumPy expressions. Both timed public calls include moments, tensor allocation and preparation; genuine original central moments are separately prepared outside timing only for the frozen per-cell checker. Default image calls include owned moments, inertia assembly and the existing C++ symmetric eigensolver; NumPy preparation, clipping and scalar-list wrapping remain providers. Unsupported solver domains retain NumPy eigvalsh primitives without native solver credit. Genuine original central moments and tensor are prepared outside timing only for the frozen solver-plus-Weyl checker.

| API | Size | Dtype | Workers | Execution | Reference ms | Current ms | Speedup |
|---|---:|---|---:|---|---:|---:|---:|
| measure.inertia_tensor | 256 | uint8 | 1 | native | 0.1416 | 0.1047 | 1.35x |
| measure.inertia_tensor_eigvals | 256 | uint8 | 1 | native | 0.1742 | 0.1249 | 1.39x |
| measure.inertia_tensor | 256 | float32 | 1 | native | 0.1193 | 0.0847 | 1.41x |
| measure.inertia_tensor_eigvals | 256 | float32 | 1 | native | 0.1555 | 0.1047 | 1.49x |
| measure.inertia_tensor | 256 | float64 | 1 | native | 0.1283 | 0.0967 | 1.33x |
| measure.inertia_tensor_eigvals | 256 | float64 | 1 | native | 0.1649 | 0.1181 | 1.40x |
| measure.inertia_tensor | 1024 | uint8 | 1 | native | 0.7669 | 0.5472 | 1.40x |
| measure.inertia_tensor_eigvals | 1024 | uint8 | 1 | native | 0.7959 | 0.5700 | 1.40x |
| measure.inertia_tensor | 1024 | float32 | 1 | native | 0.6686 | 0.4932 | 1.36x |
| measure.inertia_tensor_eigvals | 1024 | float32 | 1 | native | 0.7100 | 0.5239 | 1.36x |
| measure.inertia_tensor | 1024 | float64 | 1 | native | 0.5859 | 0.3859 | 1.52x |
| measure.inertia_tensor_eigvals | 1024 | float64 | 1 | native | 0.6256 | 0.4066 | 1.54x |
