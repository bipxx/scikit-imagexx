# Native function performance versus scikit-image

Every native public function is checked before timing. Fallback is disabled; forwarding to scikit-image cannot count as native performance. Reference thread pools use one thread. Numbers are medians of warmed allocation-inclusive calls on seeded synthetic images. Identity calls return the input unchanged; metadata calls return small values/arrays without processing pixels. Speedup is reference/current; below 1 means slower. This does not prove full API parity or universal performance. Ordinary default sums own typed block arithmetic and output partitioning. NumPy padding, block-view metadata, storage/layout preparation and allocation remain providers; custom functions/kwargs, complex padding and exceptional/type-frontier sums use literal primitive reducers without native sum credit. Half sums require original padded native/aligned C storage and block volume<=np.getbufsize(); other half layouts or buffered reductions remain literal providers and open native-coverage work. Timed default image calls include the entire padding, summation and allocation path; the frozen per-block 2*gamma_m*S checker runs outside timing.

| API | Size | Dtype | Workers | Execution | Reference ms | Current ms | Speedup |
|---|---:|---|---:|---|---:|---:|---:|
| measure.block_reduce | 256 | uint8 | 1 | native | 0.7971 | 0.0302 | 26.39x |
| measure.block_reduce | 256 | float32 | 1 | native | 0.7459 | 0.1244 | 5.99x |
| measure.block_reduce | 256 | float64 | 1 | native | 0.7524 | 0.1569 | 4.79x |
| measure.block_reduce | 1024 | uint8 | 1 | native | 12.1554 | 0.1020 | 119.22x |
| measure.block_reduce | 1024 | float32 | 1 | native | 11.2578 | 1.5430 | 7.30x |
| measure.block_reduce | 1024 | float64 | 1 | native | 11.3453 | 2.0478 | 5.54x |
