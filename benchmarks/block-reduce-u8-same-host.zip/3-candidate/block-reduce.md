# Native function performance versus scikit-image

Every native public function is checked before timing. Fallback is disabled; forwarding to scikit-image cannot count as native performance. Reference thread pools use one thread. Numbers are medians of warmed allocation-inclusive calls on seeded synthetic images. Identity calls return the input unchanged; metadata calls return small values/arrays without processing pixels. Speedup is reference/current; below 1 means slower. This does not prove full API parity or universal performance. Ordinary default sums own typed block arithmetic and output partitioning. NumPy padding, block-view metadata, storage/layout preparation and allocation remain providers; custom functions/kwargs, complex padding and exceptional/type-frontier sums use literal primitive reducers without native sum credit. Half sums require original padded native/aligned C storage and block volume<=np.getbufsize(); other half layouts or buffered reductions remain literal providers and open native-coverage work. Timed default image calls include the entire padding, summation and allocation path; the frozen per-block 2*gamma_m*S checker runs outside timing.

| API | Size | Dtype | Workers | Execution | Reference ms | Current ms | Speedup |
|---|---:|---|---:|---|---:|---:|---:|
| measure.block_reduce | 256 | uint8 | 1 | native | 0.7907 | 0.0281 | 28.13x |
| measure.block_reduce | 256 | float32 | 1 | native | 0.7350 | 0.1181 | 6.22x |
| measure.block_reduce | 256 | float64 | 1 | native | 0.7440 | 0.1507 | 4.94x |
| measure.block_reduce | 1024 | uint8 | 1 | native | 12.0694 | 0.0980 | 123.11x |
| measure.block_reduce | 1024 | float32 | 1 | native | 11.1435 | 1.5078 | 7.39x |
| measure.block_reduce | 1024 | float64 | 1 | native | 11.2682 | 1.9533 | 5.77x |
