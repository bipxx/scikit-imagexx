# RGB storage: one-thread comparison

| Case | Actual dtype | Native byte order | Original ms | Current ms | Original/current |
|---|---|---|---:|---:|---:|
| 256:native-u8 | `|u1` | True | 1.814953 | 0.479163 | 3.787757255x |
| 256:native-f32 | `<f4` | True | 0.320313 | 0.052868 | 6.058731051x |
| 256:native-f64 | `<f8` | True | 0.386003 | 0.075725 | 5.097401337x |
| 256:native-f16 | `<f2` | True | 0.820286 | 0.108692 | 7.546863270x |
| 256:swapped-f32 | `>f4` | False | 0.465192 | 0.083643 | 5.561611264x |
| 256:swapped-f64 | `>f8` | False | 0.480278 | 0.137594 | 3.490553342x |
| 1024:native-u8 | `|u1` | True | 9.873901 | 8.443852 | 1.169359790x |
| 1024:native-f32 | `<f4` | True | 4.856562 | 0.792150 | 6.130861158x |
| 1024:native-f64 | `<f8` | True | 6.073602 | 1.317304 | 4.610629607x |
| 1024:native-f16 | `<f2` | True | 12.809059 | 2.323829 | 5.512049655x |
| 1024:swapped-f32 | `>f4` | False | 7.155862 | 1.333516 | 5.366163723x |
| 1024:swapped-f64 | `>f8` | False | 7.622731 | 2.605150 | 2.926023837x |
