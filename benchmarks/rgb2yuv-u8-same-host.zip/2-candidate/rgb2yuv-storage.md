# RGB storage: one-thread comparison

| Case | Actual dtype | Native byte order | Original ms | Current ms | Original/current |
|---|---|---|---:|---:|---:|
| 256:native-u8 | `|u1` | True | 1.787833 | 0.133027 | 13.439577772x |
| 256:native-f32 | `<f4` | True | 0.318862 | 0.050386 | 6.328319492x |
| 256:native-f64 | `<f8` | True | 0.378889 | 0.077297 | 4.901744474x |
| 256:native-f16 | `<f2` | True | 0.817100 | 0.107148 | 7.625922772x |
| 256:swapped-f32 | `>f4` | False | 0.465821 | 0.082861 | 5.621692022x |
| 256:swapped-f64 | `>f8` | False | 0.469201 | 0.139795 | 3.356355877x |
| 1024:native-u8 | `|u1` | True | 9.770686 | 2.099152 | 4.654586631x |
| 1024:native-f32 | `<f4` | True | 4.910296 | 0.751685 | 6.532381379x |
| 1024:native-f64 | `<f8` | True | 5.991998 | 1.345024 | 4.454937607x |
| 1024:native-f16 | `<f2` | True | 12.864356 | 1.839569 | 6.993135892x |
| 1024:swapped-f32 | `>f4` | False | 7.180216 | 1.417950 | 5.063799014x |
| 1024:swapped-f64 | `>f8` | False | 7.521515 | 2.669770 | 2.817289715x |
