# RGB storage: one-thread comparison

| Case | Actual dtype | Native byte order | Original ms | Current ms | Original/current |
|---|---|---|---:|---:|---:|
| 256:native-u8 | `|u1` | True | 1.748546 | 0.475847 | 3.674597696x |
| 256:native-f32 | `<f4` | True | 0.321294 | 0.052502 | 6.119601495x |
| 256:native-f64 | `<f8` | True | 0.379520 | 0.075199 | 5.046908979x |
| 256:native-f16 | `<f2` | True | 0.822077 | 0.114187 | 7.199394286x |
| 256:swapped-f32 | `>f4` | False | 0.468429 | 0.083742 | 5.593736592x |
| 256:swapped-f64 | `>f8` | False | 0.478362 | 0.142305 | 3.361528707x |
| 1024:native-u8 | `|u1` | True | 9.823764 | 8.460322 | 1.161157223x |
| 1024:native-f32 | `<f4` | True | 4.867683 | 0.797233 | 6.105721916x |
| 1024:native-f64 | `<f8` | True | 6.039669 | 1.321388 | 4.570700972x |
| 1024:native-f16 | `<f2` | True | 12.753333 | 2.295753 | 5.555185565x |
| 1024:swapped-f32 | `>f4` | False | 7.139265 | 1.325924 | 5.384371317x |
| 1024:swapped-f64 | `>f8` | False | 7.649607 | 2.621832 | 2.917657641x |
