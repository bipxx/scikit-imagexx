# RGB storage: one-thread comparison

| Case | Actual dtype | Native byte order | Original ms | Current ms | Original/current |
|---|---|---|---:|---:|---:|
| 256:native-u8 | `|u1` | True | 1.775495 | 0.137385 | 12.923492991x |
| 256:native-f32 | `<f4` | True | 0.326432 | 0.053460 | 6.106076771x |
| 256:native-f64 | `<f8` | True | 0.389922 | 0.078426 | 4.971827585x |
| 256:native-f16 | `<f2` | True | 0.822004 | 0.111634 | 7.363388999x |
| 256:swapped-f32 | `>f4` | False | 0.467033 | 0.081465 | 5.732937610x |
| 256:swapped-f64 | `>f8` | False | 0.474979 | 0.147898 | 3.211531394x |
| 1024:native-u8 | `|u1` | True | 9.876532 | 2.079226 | 4.750100278x |
| 1024:native-f32 | `<f4` | True | 4.940443 | 0.754633 | 6.546818886x |
| 1024:native-f64 | `<f8` | True | 6.067201 | 1.337887 | 4.534914429x |
| 1024:native-f16 | `<f2` | True | 12.860735 | 1.831869 | 7.020554966x |
| 1024:swapped-f32 | `>f4` | False | 7.214679 | 1.434600 | 5.029053087x |
| 1024:swapped-f64 | `>f8` | False | 7.610854 | 2.600747 | 2.926410758x |
