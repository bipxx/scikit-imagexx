# Native function performance versus scikit-image

Every native public function is checked before timing. Fallback is disabled; forwarding to scikit-image cannot count as native performance. Reference thread pools use one thread. Numbers are medians of warmed allocation-inclusive calls on seeded synthetic images. Identity calls return the input unchanged; metadata calls return small values/arrays without processing pixels. Speedup is reference/current; below 1 means slower. This does not prove full API parity or universal performance. Automatic central moments use owned per-axis projections; NumPy coordinate powers, analytical preparation, diagonal summation and indexing remain providers. Finite real tensor assembly is owned C++; exceptional arithmetic retains local NumPy expressions. Both timed public calls include moments, tensor allocation and preparation; genuine original central moments are separately prepared outside timing only for the frozen per-cell checker. Default image calls include owned moments, inertia assembly and the existing C++ symmetric eigensolver; NumPy preparation, clipping and scalar-list wrapping remain providers. Unsupported solver domains retain NumPy eigvalsh primitives without native solver credit. Genuine original central moments and tensor are prepared outside timing only for the frozen solver-plus-Weyl checker.

| API | Size | Dtype | Workers | Execution | Reference ms | Current ms | Speedup |
|---|---:|---|---:|---|---:|---:|---:|
| measure.inertia_tensor | 256 | uint8 | 1 | native | 0.1490 | 0.1063 | 1.40x |
| measure.inertia_tensor_eigvals | 256 | uint8 | 1 | native | 0.1781 | 0.1389 | 1.28x |
| measure.inertia_tensor | 256 | float32 | 1 | native | 0.1289 | 0.0909 | 1.42x |
| measure.inertia_tensor_eigvals | 256 | float32 | 1 | native | 0.1540 | 0.1129 | 1.36x |
| measure.inertia_tensor | 256 | float64 | 1 | native | 0.1388 | 0.1041 | 1.33x |
| measure.inertia_tensor_eigvals | 256 | float64 | 1 | native | 0.1709 | 0.1227 | 1.39x |
| measure.inertia_tensor | 1024 | uint8 | 1 | native | 0.8135 | 0.7809 | 1.04x |
| measure.inertia_tensor_eigvals | 1024 | uint8 | 1 | native | 0.8875 | 0.8347 | 1.06x |
| measure.inertia_tensor | 1024 | float32 | 1 | native | 0.7975 | 0.6649 | 1.20x |
| measure.inertia_tensor_eigvals | 1024 | float32 | 1 | native | 0.7990 | 0.6477 | 1.23x |
| measure.inertia_tensor | 1024 | float64 | 1 | native | 0.5970 | 0.6630 | 0.90x |
| measure.inertia_tensor_eigvals | 1024 | float64 | 1 | native | 0.6954 | 0.8066 | 0.86x |
