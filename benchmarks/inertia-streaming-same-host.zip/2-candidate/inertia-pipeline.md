# Native function performance versus scikit-image

Every native public function is checked before timing. Fallback is disabled; forwarding to scikit-image cannot count as native performance. Reference thread pools use one thread. Numbers are medians of warmed allocation-inclusive calls on seeded synthetic images. Identity calls return the input unchanged; metadata calls return small values/arrays without processing pixels. Speedup is reference/current; below 1 means slower. This does not prove full API parity or universal performance. Automatic central moments use owned per-axis projections; NumPy coordinate powers, analytical preparation, diagonal summation and indexing remain providers. Finite real tensor assembly is owned C++; exceptional arithmetic retains local NumPy expressions. Both timed public calls include moments, tensor allocation and preparation; genuine original central moments are separately prepared outside timing only for the frozen per-cell checker. Default image calls include owned moments, inertia assembly and the existing C++ symmetric eigensolver; NumPy preparation, clipping and scalar-list wrapping remain providers. Unsupported solver domains retain NumPy eigvalsh primitives without native solver credit. Genuine original central moments and tensor are prepared outside timing only for the frozen solver-plus-Weyl checker.

| API | Size | Dtype | Workers | Execution | Reference ms | Current ms | Speedup |
|---|---:|---|---:|---|---:|---:|---:|
| measure.inertia_tensor | 256 | uint8 | 1 | native | 0.1510 | 0.1187 | 1.27x |
| measure.inertia_tensor_eigvals | 256 | uint8 | 1 | native | 0.2084 | 0.1372 | 1.52x |
| measure.inertia_tensor | 256 | float32 | 1 | native | 0.1272 | 0.0884 | 1.44x |
| measure.inertia_tensor_eigvals | 256 | float32 | 1 | native | 0.1866 | 0.1235 | 1.51x |
| measure.inertia_tensor | 256 | float64 | 1 | native | 0.1336 | 0.1014 | 1.32x |
| measure.inertia_tensor_eigvals | 256 | float64 | 1 | native | 0.1937 | 0.1324 | 1.46x |
| measure.inertia_tensor | 1024 | uint8 | 1 | native | 0.8355 | 0.5907 | 1.41x |
| measure.inertia_tensor_eigvals | 1024 | uint8 | 1 | native | 0.8263 | 0.5676 | 1.46x |
| measure.inertia_tensor | 1024 | float32 | 1 | native | 0.7025 | 0.6917 | 1.02x |
| measure.inertia_tensor_eigvals | 1024 | float32 | 1 | native | 0.7178 | 0.7071 | 1.02x |
| measure.inertia_tensor | 1024 | float64 | 1 | native | 0.6223 | 0.3912 | 1.59x |
| measure.inertia_tensor_eigvals | 1024 | float64 | 1 | native | 0.7457 | 0.5029 | 1.48x |
