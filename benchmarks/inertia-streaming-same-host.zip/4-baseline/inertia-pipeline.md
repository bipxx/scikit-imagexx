# Native function performance versus scikit-image

Every native public function is checked before timing. Fallback is disabled; forwarding to scikit-image cannot count as native performance. Reference thread pools use one thread. Numbers are medians of warmed allocation-inclusive calls on seeded synthetic images. Identity calls return the input unchanged; metadata calls return small values/arrays without processing pixels. Speedup is reference/current; below 1 means slower. This does not prove full API parity or universal performance. Automatic central moments use owned per-axis projections; NumPy coordinate powers, analytical preparation, diagonal summation and indexing remain providers. Finite real tensor assembly is owned C++; exceptional arithmetic retains local NumPy expressions. Both timed public calls include moments, tensor allocation and preparation; genuine original central moments are separately prepared outside timing only for the frozen per-cell checker. Default image calls include owned moments, inertia assembly and the existing C++ symmetric eigensolver; NumPy preparation, clipping and scalar-list wrapping remain providers. Unsupported solver domains retain NumPy eigvalsh primitives without native solver credit. Genuine original central moments and tensor are prepared outside timing only for the frozen solver-plus-Weyl checker.

| API | Size | Dtype | Workers | Execution | Reference ms | Current ms | Speedup |
|---|---:|---|---:|---|---:|---:|---:|
| measure.inertia_tensor | 256 | uint8 | 1 | native | 0.1475 | 0.1057 | 1.40x |
| measure.inertia_tensor_eigvals | 256 | uint8 | 1 | native | 0.1978 | 0.1285 | 1.54x |
| measure.inertia_tensor | 256 | float32 | 1 | native | 0.1243 | 0.0909 | 1.37x |
| measure.inertia_tensor_eigvals | 256 | float32 | 1 | native | 0.1758 | 0.1169 | 1.50x |
| measure.inertia_tensor | 256 | float64 | 1 | native | 0.1357 | 0.0995 | 1.36x |
| measure.inertia_tensor_eigvals | 256 | float64 | 1 | native | 0.1703 | 0.1324 | 1.29x |
| measure.inertia_tensor | 1024 | uint8 | 1 | native | 0.7538 | 0.7566 | 1.00x |
| measure.inertia_tensor_eigvals | 1024 | uint8 | 1 | native | 0.8363 | 0.8033 | 1.04x |
| measure.inertia_tensor | 1024 | float32 | 1 | native | 0.7344 | 0.7557 | 0.97x |
| measure.inertia_tensor_eigvals | 1024 | float32 | 1 | native | 0.7574 | 0.7923 | 0.96x |
| measure.inertia_tensor | 1024 | float64 | 1 | native | 0.6062 | 0.6561 | 0.92x |
| measure.inertia_tensor_eigvals | 1024 | float64 | 1 | native | 0.6396 | 0.7874 | 0.81x |
