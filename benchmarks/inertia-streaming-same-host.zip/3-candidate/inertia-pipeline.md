# Native function performance versus scikit-image

Every native public function is checked before timing. Fallback is disabled; forwarding to scikit-image cannot count as native performance. Reference thread pools use one thread. Numbers are medians of warmed allocation-inclusive calls on seeded synthetic images. Identity calls return the input unchanged; metadata calls return small values/arrays without processing pixels. Speedup is reference/current; below 1 means slower. This does not prove full API parity or universal performance. Automatic central moments use owned per-axis projections; NumPy coordinate powers, analytical preparation, diagonal summation and indexing remain providers. Finite real tensor assembly is owned C++; exceptional arithmetic retains local NumPy expressions. Both timed public calls include moments, tensor allocation and preparation; genuine original central moments are separately prepared outside timing only for the frozen per-cell checker. Default image calls include owned moments, inertia assembly and the existing C++ symmetric eigensolver; NumPy preparation, clipping and scalar-list wrapping remain providers. Unsupported solver domains retain NumPy eigvalsh primitives without native solver credit. Genuine original central moments and tensor are prepared outside timing only for the frozen solver-plus-Weyl checker.

| API | Size | Dtype | Workers | Execution | Reference ms | Current ms | Speedup |
|---|---:|---|---:|---|---:|---:|---:|
| measure.inertia_tensor | 256 | uint8 | 1 | native | 0.1555 | 0.1104 | 1.41x |
| measure.inertia_tensor_eigvals | 256 | uint8 | 1 | native | 0.2134 | 0.1512 | 1.41x |
| measure.inertia_tensor | 256 | float32 | 1 | native | 0.1373 | 0.0971 | 1.41x |
| measure.inertia_tensor_eigvals | 256 | float32 | 1 | native | 0.1564 | 0.1042 | 1.50x |
| measure.inertia_tensor | 256 | float64 | 1 | native | 0.1493 | 0.1144 | 1.30x |
| measure.inertia_tensor_eigvals | 256 | float64 | 1 | native | 0.1693 | 0.1210 | 1.40x |
| measure.inertia_tensor | 1024 | uint8 | 1 | native | 0.7459 | 0.5395 | 1.38x |
| measure.inertia_tensor_eigvals | 1024 | uint8 | 1 | native | 0.8166 | 0.6077 | 1.34x |
| measure.inertia_tensor | 1024 | float32 | 1 | native | 0.7607 | 0.8531 | 0.89x |
| measure.inertia_tensor_eigvals | 1024 | float32 | 1 | native | 0.7872 | 0.8478 | 0.93x |
| measure.inertia_tensor | 1024 | float64 | 1 | native | 0.6265 | 0.4301 | 1.46x |
| measure.inertia_tensor_eigvals | 1024 | float64 | 1 | native | 0.6724 | 0.4619 | 1.46x |
