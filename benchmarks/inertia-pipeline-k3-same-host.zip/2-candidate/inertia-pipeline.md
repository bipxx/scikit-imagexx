# Native function performance versus scikit-image

Every native public function is checked before timing. Fallback is disabled; forwarding to scikit-image cannot count as native performance. Reference thread pools use one thread. Numbers are medians of warmed allocation-inclusive calls on seeded synthetic images. Identity calls return the input unchanged; metadata calls return small values/arrays without processing pixels. Speedup is reference/current; below 1 means slower. This does not prove full API parity or universal performance. Automatic central moments use owned per-axis projections; NumPy coordinate powers, analytical preparation, diagonal summation and indexing remain providers. Finite real tensor assembly is owned C++; exceptional arithmetic retains local NumPy expressions. Both timed public calls include moments, tensor allocation and preparation; genuine original central moments are separately prepared outside timing only for the frozen per-cell checker. Default image calls include owned moments, inertia assembly and the existing C++ symmetric eigensolver; NumPy preparation, clipping and scalar-list wrapping remain providers. Unsupported solver domains retain NumPy eigvalsh primitives without native solver credit. Genuine original central moments and tensor are prepared outside timing only for the frozen solver-plus-Weyl checker.

| API | Size | Dtype | Workers | Execution | Reference ms | Current ms | Speedup |
|---|---:|---|---:|---|---:|---:|---:|
| measure.inertia_tensor | 256 | uint8 | 1 | native | 0.1439 | 0.1046 | 1.38x |
| measure.inertia_tensor_eigvals | 256 | uint8 | 1 | native | 0.1826 | 0.1321 | 1.38x |
| measure.inertia_tensor | 256 | float32 | 1 | native | 0.1177 | 0.0890 | 1.32x |
| measure.inertia_tensor_eigvals | 256 | float32 | 1 | native | 0.1556 | 0.1053 | 1.48x |
| measure.inertia_tensor | 256 | float64 | 1 | native | 0.1302 | 0.0998 | 1.31x |
| measure.inertia_tensor_eigvals | 256 | float64 | 1 | native | 0.1632 | 0.1185 | 1.38x |
| measure.inertia_tensor | 1024 | uint8 | 1 | native | 0.7653 | 0.7922 | 0.97x |
| measure.inertia_tensor_eigvals | 1024 | uint8 | 1 | native | 0.8029 | 0.8234 | 0.98x |
| measure.inertia_tensor | 1024 | float32 | 1 | native | 0.6646 | 0.5148 | 1.29x |
| measure.inertia_tensor_eigvals | 1024 | float32 | 1 | native | 0.7815 | 0.5485 | 1.42x |
| measure.inertia_tensor | 1024 | float64 | 1 | native | 0.6027 | 0.8180 | 0.74x |
| measure.inertia_tensor_eigvals | 1024 | float64 | 1 | native | 0.6735 | 1.0314 | 0.65x |
