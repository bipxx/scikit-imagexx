# Native function performance versus scikit-image

Every native public function is checked before timing. Fallback is disabled; forwarding to scikit-image cannot count as native performance. Reference thread pools use one thread. Numbers are medians of warmed allocation-inclusive calls on seeded synthetic images. Identity calls return the input unchanged; metadata calls return small values/arrays without processing pixels. Speedup is reference/current; below 1 means slower. This does not prove full API parity or universal performance. Automatic central moments use owned per-axis projections; NumPy coordinate powers, analytical preparation, diagonal summation and indexing remain providers. Finite real tensor assembly is owned C++; exceptional arithmetic retains local NumPy expressions. Both timed public calls include moments, tensor allocation and preparation; genuine original central moments are separately prepared outside timing only for the frozen per-cell checker. Default image calls include owned moments, inertia assembly and the existing C++ symmetric eigensolver; NumPy preparation, clipping and scalar-list wrapping remain providers. Unsupported solver domains retain NumPy eigvalsh primitives without native solver credit. Genuine original central moments and tensor are prepared outside timing only for the frozen solver-plus-Weyl checker.

| API | Size | Dtype | Workers | Execution | Reference ms | Current ms | Speedup |
|---|---:|---|---:|---|---:|---:|---:|
| measure.inertia_tensor | 256 | uint8 | 1 | native | 0.1374 | 0.1881 | 0.73x |
| measure.inertia_tensor_eigvals | 256 | uint8 | 1 | native | 0.1726 | 0.1914 | 0.90x |
| measure.inertia_tensor | 256 | float32 | 1 | native | 0.1184 | 0.1058 | 1.12x |
| measure.inertia_tensor_eigvals | 256 | float32 | 1 | native | 0.1539 | 0.1289 | 1.19x |
| measure.inertia_tensor | 256 | float64 | 1 | native | 0.1264 | 0.1660 | 0.76x |
| measure.inertia_tensor_eigvals | 256 | float64 | 1 | native | 0.1621 | 0.1886 | 0.86x |
| measure.inertia_tensor | 1024 | uint8 | 1 | native | 0.7656 | 6.8298 | 0.11x |
| measure.inertia_tensor_eigvals | 1024 | uint8 | 1 | native | 0.8319 | 6.8887 | 0.12x |
| measure.inertia_tensor | 1024 | float32 | 1 | native | 0.6754 | 2.0490 | 0.33x |
| measure.inertia_tensor_eigvals | 1024 | float32 | 1 | native | 0.7397 | 2.0922 | 0.35x |
| measure.inertia_tensor | 1024 | float64 | 1 | native | 0.6031 | 6.7350 | 0.09x |
| measure.inertia_tensor_eigvals | 1024 | float64 | 1 | native | 0.6281 | 6.7580 | 0.09x |
