# Native function performance versus scikit-image

Every native public function is checked before timing. Fallback is disabled; forwarding to scikit-image cannot count as native performance. Reference thread pools use one thread. Numbers are medians of warmed allocation-inclusive calls on seeded synthetic images. Identity calls return the input unchanged; metadata calls return small values/arrays without processing pixels. Speedup is reference/current; below 1 means slower. This does not prove full API parity or universal performance. Automatic central moments use owned per-axis projections; NumPy coordinate powers, analytical preparation, diagonal summation and indexing remain providers. Finite real tensor assembly is owned C++; exceptional arithmetic retains local NumPy expressions. Both timed public calls include moments, tensor allocation and preparation; genuine original central moments are separately prepared outside timing only for the frozen per-cell checker. Default image calls include owned moments, inertia assembly and the existing C++ symmetric eigensolver; NumPy preparation, clipping and scalar-list wrapping remain providers. Unsupported solver domains retain NumPy eigvalsh primitives without native solver credit. Genuine original central moments and tensor are prepared outside timing only for the frozen solver-plus-Weyl checker.

| API | Size | Dtype | Workers | Execution | Reference ms | Current ms | Speedup |
|---|---:|---|---:|---|---:|---:|---:|
| measure.inertia_tensor | 256 | uint8 | 1 | native | 0.1481 | 0.2277 | 0.65x |
| measure.inertia_tensor_eigvals | 256 | uint8 | 1 | native | 0.1811 | 0.2393 | 0.76x |
| measure.inertia_tensor | 256 | float32 | 1 | native | 0.1170 | 0.0997 | 1.17x |
| measure.inertia_tensor_eigvals | 256 | float32 | 1 | native | 0.1570 | 0.1207 | 1.30x |
| measure.inertia_tensor | 256 | float64 | 1 | native | 0.1348 | 0.2096 | 0.64x |
| measure.inertia_tensor_eigvals | 256 | float64 | 1 | native | 0.1702 | 0.2329 | 0.73x |
| measure.inertia_tensor | 1024 | uint8 | 1 | native | 0.7726 | 7.0732 | 0.11x |
| measure.inertia_tensor_eigvals | 1024 | uint8 | 1 | native | 0.8150 | 6.9681 | 0.12x |
| measure.inertia_tensor | 1024 | float32 | 1 | native | 0.6858 | 3.0073 | 0.23x |
| measure.inertia_tensor_eigvals | 1024 | float32 | 1 | native | 0.7124 | 3.0454 | 0.23x |
| measure.inertia_tensor | 1024 | float64 | 1 | native | 0.6104 | 4.5371 | 0.13x |
| measure.inertia_tensor_eigvals | 1024 | float64 | 1 | native | 0.6342 | 4.5575 | 0.14x |
