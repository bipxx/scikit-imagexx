# Native function performance versus scikit-image

Every native public function is checked before timing. Fallback is disabled; forwarding to scikit-image cannot count as native performance. Reference thread pools use one thread. Numbers are medians of warmed allocation-inclusive calls on seeded synthetic images. Identity calls return the input unchanged; metadata calls return small values/arrays without processing pixels. Speedup is reference/current; below 1 means slower. This does not prove full API parity or universal performance. Automatic central moments use owned per-axis projections; NumPy coordinate powers, analytical preparation, diagonal summation and indexing remain providers. Finite real tensor assembly is owned C++; exceptional arithmetic retains local NumPy expressions. Both timed public calls include moments, tensor allocation and preparation; genuine original central moments are separately prepared outside timing only for the frozen per-cell checker. Default image calls include owned moments, inertia assembly and the existing C++ symmetric eigensolver; NumPy preparation, clipping and scalar-list wrapping remain providers. Unsupported solver domains retain NumPy eigvalsh primitives without native solver credit. Genuine original central moments and tensor are prepared outside timing only for the frozen solver-plus-Weyl checker.

| API | Size | Dtype | Workers | Execution | Reference ms | Current ms | Speedup |
|---|---:|---|---:|---|---:|---:|---:|
| measure.inertia_tensor | 256 | uint8 | 1 | native | 0.1441 | 0.1041 | 1.38x |
| measure.inertia_tensor_eigvals | 256 | uint8 | 1 | native | 0.1750 | 0.1242 | 1.41x |
| measure.inertia_tensor | 256 | float32 | 1 | native | 0.1188 | 0.0866 | 1.37x |
| measure.inertia_tensor_eigvals | 256 | float32 | 1 | native | 0.1561 | 0.1101 | 1.42x |
| measure.inertia_tensor | 256 | float64 | 1 | native | 0.1290 | 0.0961 | 1.34x |
| measure.inertia_tensor_eigvals | 256 | float64 | 1 | native | 0.1641 | 0.1209 | 1.36x |
| measure.inertia_tensor | 1024 | uint8 | 1 | native | 0.7653 | 0.7814 | 0.98x |
| measure.inertia_tensor_eigvals | 1024 | uint8 | 1 | native | 0.8161 | 0.8337 | 0.98x |
| measure.inertia_tensor | 1024 | float32 | 1 | native | 0.6402 | 0.5903 | 1.08x |
| measure.inertia_tensor_eigvals | 1024 | float32 | 1 | native | 0.6698 | 0.6200 | 1.08x |
| measure.inertia_tensor | 1024 | float64 | 1 | native | 0.5863 | 0.6941 | 0.84x |
| measure.inertia_tensor_eigvals | 1024 | float64 | 1 | native | 0.6301 | 0.8181 | 0.77x |
