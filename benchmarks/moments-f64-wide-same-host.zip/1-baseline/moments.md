# Native function performance versus scikit-image

Every native public function is checked before timing. Fallback is disabled; forwarding to scikit-image cannot count as native performance. Reference thread pools use one thread. Numbers are medians of warmed allocation-inclusive calls on seeded synthetic images. Identity calls return the input unchanged; metadata calls return small values/arrays without processing pixels. Speedup is reference/current; below 1 means slower. This does not prove full API parity or universal performance. NumPy dtype promotion, coordinate powers and layout preparation, and the literal analytical central-moment and centroid-ratio Python/NumPy shell remain providers; owned typed C++ per-axis projections capture floating-point flags and use the shared global workers.

| API | Size | Dtype | Workers | Execution | Reference ms | Current ms | Speedup |
|---|---:|---|---:|---|---:|---:|---:|
| measure.moments | 256 | uint8 | 1 | native | 0.0825 | 0.0523 | 1.58x |
| measure.moments_central | 256 | uint8 | 1 | native | 0.0928 | 0.0602 | 1.54x |
| measure.centroid | 256 | uint8 | 1 | native | 0.0806 | 0.0537 | 1.50x |
| measure.moments | 256 | float32 | 1 | native | 0.0650 | 0.0371 | 1.75x |
| measure.moments_central | 256 | float32 | 1 | native | 0.0738 | 0.0425 | 1.74x |
| measure.centroid | 256 | float32 | 1 | native | 0.0679 | 0.0385 | 1.76x |
| measure.moments | 256 | float64 | 1 | native | 0.0775 | 0.0500 | 1.55x |
| measure.moments_central | 256 | float64 | 1 | native | 0.0831 | 0.0546 | 1.52x |
| measure.centroid | 256 | float64 | 1 | native | 0.0722 | 0.0496 | 1.46x |
| measure.moments | 1024 | uint8 | 1 | native | 0.4578 | 1.2842 | 0.36x |
| measure.moments_central | 1024 | uint8 | 1 | native | 0.4727 | 1.1995 | 0.39x |
| measure.centroid | 1024 | uint8 | 1 | native | 0.4268 | 1.4471 | 0.29x |
| measure.moments | 1024 | float32 | 1 | native | 0.3689 | 0.6327 | 0.58x |
| measure.moments_central | 1024 | float32 | 1 | native | 0.3808 | 0.6481 | 0.59x |
| measure.centroid | 1024 | float32 | 1 | native | 0.3582 | 0.7860 | 0.46x |
| measure.moments | 1024 | float64 | 1 | native | 0.3610 | 1.3178 | 0.27x |
| measure.moments_central | 1024 | float64 | 1 | native | 0.3550 | 1.3282 | 0.27x |
| measure.centroid | 1024 | float64 | 1 | native | 0.3269 | 1.8241 | 0.18x |
