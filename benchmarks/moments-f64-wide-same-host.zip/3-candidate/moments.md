# Native function performance versus scikit-image

Every native public function is checked before timing. Fallback is disabled; forwarding to scikit-image cannot count as native performance. Reference thread pools use one thread. Numbers are medians of warmed allocation-inclusive calls on seeded synthetic images. Identity calls return the input unchanged; metadata calls return small values/arrays without processing pixels. Speedup is reference/current; below 1 means slower. This does not prove full API parity or universal performance. NumPy dtype promotion, coordinate powers and layout preparation, and the literal analytical central-moment and centroid-ratio Python/NumPy shell remain providers; owned typed C++ per-axis projections capture floating-point flags and use the shared global workers.

| API | Size | Dtype | Workers | Execution | Reference ms | Current ms | Speedup |
|---|---:|---|---:|---|---:|---:|---:|
| measure.moments | 256 | uint8 | 1 | native | 0.0808 | 0.0456 | 1.77x |
| measure.moments_central | 256 | uint8 | 1 | native | 0.0884 | 0.0511 | 1.73x |
| measure.centroid | 256 | uint8 | 1 | native | 0.0794 | 0.0492 | 1.61x |
| measure.moments | 256 | float32 | 1 | native | 0.0651 | 0.0359 | 1.81x |
| measure.moments_central | 256 | float32 | 1 | native | 0.0773 | 0.0440 | 1.76x |
| measure.centroid | 256 | float32 | 1 | native | 0.0694 | 0.0394 | 1.76x |
| measure.moments | 256 | float64 | 1 | native | 0.0767 | 0.0430 | 1.78x |
| measure.moments_central | 256 | float64 | 1 | native | 0.0864 | 0.0477 | 1.81x |
| measure.centroid | 256 | float64 | 1 | native | 0.0723 | 0.0453 | 1.60x |
| measure.moments | 1024 | uint8 | 1 | native | 0.4662 | 0.6810 | 0.68x |
| measure.moments_central | 1024 | uint8 | 1 | native | 0.4722 | 0.6960 | 0.68x |
| measure.centroid | 1024 | uint8 | 1 | native | 0.4364 | 0.8541 | 0.51x |
| measure.moments | 1024 | float32 | 1 | native | 0.3449 | 0.5096 | 0.68x |
| measure.moments_central | 1024 | float32 | 1 | native | 0.3571 | 0.5212 | 0.69x |
| measure.centroid | 1024 | float32 | 1 | native | 0.3463 | 0.6076 | 0.57x |
| measure.moments | 1024 | float64 | 1 | native | 0.3794 | 0.6321 | 0.60x |
| measure.moments_central | 1024 | float64 | 1 | native | 0.4043 | 0.7555 | 0.54x |
| measure.centroid | 1024 | float64 | 1 | native | 0.3652 | 0.8210 | 0.44x |
