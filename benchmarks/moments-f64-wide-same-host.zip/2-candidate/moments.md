# Native function performance versus scikit-image

Every native public function is checked before timing. Fallback is disabled; forwarding to scikit-image cannot count as native performance. Reference thread pools use one thread. Numbers are medians of warmed allocation-inclusive calls on seeded synthetic images. Identity calls return the input unchanged; metadata calls return small values/arrays without processing pixels. Speedup is reference/current; below 1 means slower. This does not prove full API parity or universal performance. NumPy dtype promotion, coordinate powers and layout preparation, and the literal analytical central-moment and centroid-ratio Python/NumPy shell remain providers; owned typed C++ per-axis projections capture floating-point flags and use the shared global workers.

| API | Size | Dtype | Workers | Execution | Reference ms | Current ms | Speedup |
|---|---:|---|---:|---|---:|---:|---:|
| measure.moments | 256 | uint8 | 1 | native | 0.0825 | 0.0485 | 1.70x |
| measure.moments_central | 256 | uint8 | 1 | native | 0.0898 | 0.0525 | 1.71x |
| measure.centroid | 256 | uint8 | 1 | native | 0.0821 | 0.0506 | 1.62x |
| measure.moments | 256 | float32 | 1 | native | 0.0654 | 0.0374 | 1.75x |
| measure.moments_central | 256 | float32 | 1 | native | 0.0756 | 0.0418 | 1.81x |
| measure.centroid | 256 | float32 | 1 | native | 0.0647 | 0.0368 | 1.76x |
| measure.moments | 256 | float64 | 1 | native | 0.0734 | 0.0408 | 1.80x |
| measure.moments_central | 256 | float64 | 1 | native | 0.0835 | 0.0466 | 1.79x |
| measure.centroid | 256 | float64 | 1 | native | 0.0740 | 0.0443 | 1.67x |
| measure.moments | 1024 | uint8 | 1 | native | 0.4825 | 0.7048 | 0.68x |
| measure.moments_central | 1024 | uint8 | 1 | native | 0.4861 | 0.6798 | 0.72x |
| measure.centroid | 1024 | uint8 | 1 | native | 0.4453 | 0.9477 | 0.47x |
| measure.moments | 1024 | float32 | 1 | native | 0.3506 | 0.4484 | 0.78x |
| measure.moments_central | 1024 | float32 | 1 | native | 0.3450 | 0.4504 | 0.77x |
| measure.centroid | 1024 | float32 | 1 | native | 0.3336 | 0.4965 | 0.67x |
| measure.moments | 1024 | float64 | 1 | native | 0.3745 | 0.6158 | 0.61x |
| measure.moments_central | 1024 | float64 | 1 | native | 0.3848 | 0.6286 | 0.61x |
| measure.centroid | 1024 | float64 | 1 | native | 0.3560 | 0.7806 | 0.46x |
