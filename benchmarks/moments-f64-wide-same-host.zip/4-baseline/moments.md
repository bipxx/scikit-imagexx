# Native function performance versus scikit-image

Every native public function is checked before timing. Fallback is disabled; forwarding to scikit-image cannot count as native performance. Reference thread pools use one thread. Numbers are medians of warmed allocation-inclusive calls on seeded synthetic images. Identity calls return the input unchanged; metadata calls return small values/arrays without processing pixels. Speedup is reference/current; below 1 means slower. This does not prove full API parity or universal performance. NumPy dtype promotion, coordinate powers and layout preparation, and the literal analytical central-moment and centroid-ratio Python/NumPy shell remain providers; owned typed C++ per-axis projections capture floating-point flags and use the shared global workers.

| API | Size | Dtype | Workers | Execution | Reference ms | Current ms | Speedup |
|---|---:|---|---:|---|---:|---:|---:|
| measure.moments | 256 | uint8 | 1 | native | 0.0845 | 0.0584 | 1.45x |
| measure.moments_central | 256 | uint8 | 1 | native | 0.0933 | 0.0630 | 1.48x |
| measure.centroid | 256 | uint8 | 1 | native | 0.0797 | 0.0591 | 1.35x |
| measure.moments | 256 | float32 | 1 | native | 0.0622 | 0.0351 | 1.77x |
| measure.moments_central | 256 | float32 | 1 | native | 0.0737 | 0.0418 | 1.76x |
| measure.centroid | 256 | float32 | 1 | native | 0.0630 | 0.0360 | 1.75x |
| measure.moments | 256 | float64 | 1 | native | 0.0746 | 0.0501 | 1.49x |
| measure.moments_central | 256 | float64 | 1 | native | 0.0852 | 0.0546 | 1.56x |
| measure.centroid | 256 | float64 | 1 | native | 0.0710 | 0.0532 | 1.34x |
| measure.moments | 1024 | uint8 | 1 | native | 0.4536 | 1.1839 | 0.38x |
| measure.moments_central | 1024 | uint8 | 1 | native | 0.4798 | 1.1384 | 0.42x |
| measure.centroid | 1024 | uint8 | 1 | native | 0.4224 | 1.3515 | 0.31x |
| measure.moments | 1024 | float32 | 1 | native | 0.3485 | 0.5773 | 0.60x |
| measure.moments_central | 1024 | float32 | 1 | native | 0.3661 | 0.5953 | 0.62x |
| measure.centroid | 1024 | float32 | 1 | native | 0.3577 | 0.7923 | 0.45x |
| measure.moments | 1024 | float64 | 1 | native | 0.3588 | 1.0340 | 0.35x |
| measure.moments_central | 1024 | float64 | 1 | native | 0.3680 | 1.0283 | 0.36x |
| measure.centroid | 1024 | float64 | 1 | native | 0.3278 | 1.2356 | 0.27x |
