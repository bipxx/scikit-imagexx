# Native function performance versus scikit-image

Every native public function is checked before timing. Fallback is disabled; forwarding to scikit-image cannot count as native performance. Reference thread pools use one thread. Numbers are medians of warmed allocation-inclusive calls on seeded synthetic images. Identity calls return the input unchanged; metadata calls return small values/arrays without processing pixels. Speedup is reference/current; below 1 means slower. This does not prove full API parity or universal performance. Ordinary real thresholding, zero-boundary 2x2 stencil histogram and the 16-term weighted sum are owned C++. NumPy/Python coefficient construction, scalar boxing and input/storage preparation remain explicit; special input types retain NumPy/SciPy count providers. Timed default directions4 calls include all preparation, histogram, weighted arithmetic and allocation. The frozen exact-rational 2*gamma_32*S checker runs outside timing.

| API | Size | Dtype | Workers | Execution | Reference ms | Current ms | Speedup |
|---|---:|---|---:|---|---:|---:|---:|
| measure.perimeter_crofton | 256 | uint8 | 1 | native | 0.6989 | 0.0965 | 7.24x |
| measure.perimeter_crofton | 256 | float32 | 1 | native | 0.7042 | 0.1054 | 6.68x |
| measure.perimeter_crofton | 256 | float64 | 1 | native | 0.7055 | 0.1155 | 6.11x |
| measure.perimeter_crofton | 1024 | uint8 | 1 | native | 9.3400 | 1.2599 | 7.41x |
| measure.perimeter_crofton | 1024 | float32 | 1 | native | 9.4239 | 1.3679 | 6.89x |
| measure.perimeter_crofton | 1024 | float64 | 1 | native | 9.3814 | 1.5350 | 6.11x |
