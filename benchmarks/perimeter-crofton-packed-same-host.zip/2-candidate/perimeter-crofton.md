# Native function performance versus scikit-image

Every native public function is checked before timing. Fallback is disabled; forwarding to scikit-image cannot count as native performance. Reference thread pools use one thread. Numbers are medians of warmed allocation-inclusive calls on seeded synthetic images. Identity calls return the input unchanged; metadata calls return small values/arrays without processing pixels. Speedup is reference/current; below 1 means slower. This does not prove full API parity or universal performance. Ordinary real thresholding, zero-boundary 2x2 stencil histogram and the 16-term weighted sum are owned C++. NumPy/Python coefficient construction, scalar boxing and input/storage preparation remain explicit; special input types retain NumPy/SciPy count providers. Timed default directions4 calls include all preparation, histogram, weighted arithmetic and allocation. The frozen exact-rational 2*gamma_32*S checker runs outside timing.

| API | Size | Dtype | Workers | Execution | Reference ms | Current ms | Speedup |
|---|---:|---|---:|---|---:|---:|---:|
| measure.perimeter_crofton | 256 | uint8 | 1 | native | 0.6983 | 0.0967 | 7.22x |
| measure.perimeter_crofton | 256 | float32 | 1 | native | 0.7011 | 0.1048 | 6.69x |
| measure.perimeter_crofton | 256 | float64 | 1 | native | 0.7013 | 0.1162 | 6.04x |
| measure.perimeter_crofton | 1024 | uint8 | 1 | native | 9.3872 | 1.2648 | 7.42x |
| measure.perimeter_crofton | 1024 | float32 | 1 | native | 9.3472 | 1.3833 | 6.76x |
| measure.perimeter_crofton | 1024 | float64 | 1 | native | 9.5191 | 1.5275 | 6.23x |
